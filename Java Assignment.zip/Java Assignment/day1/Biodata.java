package day1;
import java.util.*;
public class Biodata {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a roll no= ");
		int rollno=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter a name= ");
		String name=sc.nextLine();
		System.out.println("Enter a age");
		int age=sc.nextInt();
		System.out.println("Enter a heght= ");
		float height=sc.nextFloat();
		System.out.println("Roll no= "+rollno+"\t"+"Name= "+name+"\t"+"age: "+age+"\t"+"Height= "+height+"\t"+"age: "+age+"\t");
	}
}
