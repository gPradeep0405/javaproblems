package day1;
import java.util.*;
public class ques_1 {
	public static void main(String[] arg) {
		System.out.println("Pradeep");
		System.out.println("First line ");
		System.out.print("Second line");
		System.out.println(" Third line");
		System.out.print("Fourth line");
	}

}
