package day2;
import java.util.*;
public class grade {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter a Mark =  ");
		int grade=sc.nextInt();
		
		
		if(grade>=90) {
			System.out.print(" Grade: A");
		}else if(grade>=80 && grade<90) {
			System.out.print(" Grade: B");
		}else if(grade>=70 && grade<80) {
			System.out.print(" Grade: C");
		}else if(grade>=60 && grade<70) {
			System.out.print(" Grade: D");
		}				
		else {
			System.out.print("Fail");
		}
		
		
	}

}
