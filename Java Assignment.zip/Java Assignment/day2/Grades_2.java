package day2;
import java.util.*;
public class Grades_2 {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int mark=sc.nextInt();
		
		if(mark>=90) {
			System.out.println("Grade: A");
		}else if(mark>=70 && mark<90)
			System.out.println("Grade: B");
		else if(mark>50 && mark<70)
			System.out.println("Grade: C");
		else
			System.out.println("Grade: Fail");

	}

}
