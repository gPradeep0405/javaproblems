package day2;

import java.util.Scanner;

public class bankbalance {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Current balance: ");
		float currentbal=sc.nextFloat();
		System.out.println("Withdraw amount: ");
		float withdraw=sc.nextFloat();
		float newbalance=currentbal-withdraw;
		if(currentbal<withdraw) {
			System.out.print("error insufficiant balance");
		}else{
			System.out.print("Withdraw Successfull");
			System.out.print(" Amount balance "+newbalance);
		}
	}

}
