package day2;
import java.util.*;
public class Vote {

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		int vote=sc.nextInt();
		
		if(vote>=18)
			System.out.println("You are eligible to vote");
		else
			System.out.println("You are not eligible to vote");

	}

}
