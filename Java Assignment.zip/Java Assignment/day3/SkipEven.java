package day3;
import java.util.*;
import java.util.Scanner;

public class SkipEven {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        System.out.print("Enter a positive integer: ");
        int n = scanner.nextInt();


        if (n <= 0) {
            System.out.println("Please enter a positive integer.");
            return;
        }
        
        System.out.println("Odd numbers from 1 to " + n + ":");
        
        for (int i = 1; i <= n; i++) {
            
            if (i % 2 == 0) {
                continue;
            }
            
            System.out.print(i + " ");
        }
        
        System.out.println();
        scanner.close();
    }
}

