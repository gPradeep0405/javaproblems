package day3;
import java.util.Scanner;

public class UserAuthentication {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        
        final String correctPassword = "secret123";
        
        
        while (true) {
            System.out.print("Enter password: ");
            String enteredPassword = scanner.nextLine();
            
            
            if (enteredPassword.equals(correctPassword)) {
                System.out.println("Password accepted");
                break; 
            } else {
                System.out.println("Incorrect password. Try again.");
            }
        }
        
        scanner.close();
    }
}
