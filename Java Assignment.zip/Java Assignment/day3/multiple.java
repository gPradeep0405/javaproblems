package day3;
import java.util.*;
public class multiple {
	public static void main(String[] args) {
		Random sc=new Random();
		while(true) {			
			int num1=sc.nextInt(11);
			int num2=sc.nextInt(11);
			int mul=num1*num2;
			System.out.println("What is "+num1+"*"+num2+": ");	
			Scanner obj=new Scanner(System.in);
			int ans=obj.nextInt();
			if(ans==0) {
				System.out.println("Thank you");
				break;				
			}else if(mul==ans) 
				System.out.print("Correct");	
			else
				System.out.println("Incorrect");
		
	}

	}
}
