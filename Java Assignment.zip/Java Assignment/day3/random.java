package day3;
import java.util.*;
public class random {
	public static void main(String[] args){
		Scanner scan=new Scanner(System.in);
		Random rand=new Random();
		while(true) {
			System.out.println("Welcome to the game");
			System.out.println("Guess the number");
			
			int r=rand.nextInt(0,101);
			System.out.println("Enter the guess number= ");
			int g=scan.nextInt();
			if(g==r) {
				System.out.print("congradulation!");
				break;
			}
			if(g>r) {
				System.out.print("too high!");
			}
			else if(g<r)
				System.out.println("too low");
			else
				System.out.print("Wrong");
			
							
		}
     }
}


