package day3;
import java.util.Scanner;
public class pyramidpattern {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);        
        System.out.print("Enter the number of levels for the pyramid: ");
        int n = scanner.nextInt();        
        if (n <= 0) {
            System.out.println("The number must be positive.");
        } else {
            for (int i = 1; i <= n; i++) {
                for (int j = n; j > i; j--) {
                    System.out.print(" ");
                }
                for (int k = 1; k <= (2 * i - 1); k++) {
                    System.out.print("*");
                }
                System.out.println();
            }
        }
        scanner.close();
    }
}
