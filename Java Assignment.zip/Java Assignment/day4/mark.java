package day4;
import java.util.*;
public class mark {
	 public static void main(String args[]){
	        Scanner obj=new Scanner(System.in);
	        int num=5;
	        double[] scores=new double[num];
	        for(int i=0;i<num;i++)
	        {
	        	System.out.print("Enter a scores: "+(i+1)+":");
	        	scores[i]=obj.nextDouble();
	        	
	        }
	        int sum=0;
	        for(int i=0;i<scores.length;i++)
	        	sum+=scores[i];
	        double average=sum/scores.length;
	        System.out.println("Average: "+scores[4]);
	        Arrays.sort(scores);
	        System.out.println("Maximum: "+scores[4]);
	        System.out.print("Minimum: "+scores[0]);
	        

	 }

}
