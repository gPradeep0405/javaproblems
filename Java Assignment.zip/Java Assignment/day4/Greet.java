package day4;

public class Greet {

	public static void main(String[] args) {
		String[] students= {"Alice","Bob","Charlotte","David","Eve"};
		
		for(String temp:students)
			System.out.println("Hello, "+temp+"!");

	}

}
