package day4;
import java.util.*;
public class grades {
	public static void main(String[] args) {
		int[][] grades=new int[5][2];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<5;i++) {
			System.out.println("Enter grades for student "+(i+1)+": ");
			System.out.print("Math: ");
			grades[i][0]=sc.nextInt();
			System.out.print("Science: ");
			grades[i][1]=sc.nextInt();
			
		}
		printGrades(grades);
        
    }
    public static void printGrades(int[][] grades) {
        for (int i = 0; i < grades.length; i++)
        	System.out.println("Student " + (i + 1) + ": Math: " + grades[i][0] + ", Science: " + grades[i][1]);
	}

}
